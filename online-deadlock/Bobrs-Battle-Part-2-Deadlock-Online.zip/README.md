# Bobrs Battle Part 2

Стабильная версия `v2.1-new-cards` включает 12 утверждённых карточек и обновлённое расписание первого драфта. [История изменений](CHANGELOG.md)

## Локальный запуск

1. Войдите в GitHub под аккаунтом с доступом к приватному репозиторию. [Скачать Bobrs-Battle-Part-2-v2.1-Final.zip](https://github.com/BobrikIndeadlock/Bobrs-Battle-Part-2/raw/gothic-visual-upgrade-downloads/Bobrs-Battle-Part-2-v2.1-Final.zip)
2. Распакуйте архив целиком. Оставьте каталоги `code/` и `media/` рядом с `index.html`.
3. На компьютере откройте `index.html` в браузере. На iPhone распакуйте ZIP в приложении «Файлы», затем откройте `index.html` из полученной папки через HTML Web Preview. Если приложение запросит доступ к локальным файлам, выберите всю распакованную папку.

Распакованная игра запускается по `file://` без интернета, сервера и сборки. Видео и остальные ресурсы уже входят в ZIP.

### Запуск из Git

Для рабочей копии укажите тег релиза и загрузите финальный ролик через Git LFS.
Инструкции по установке доступны на [Git LFS](https://git-lfs.com/).

```sh
git lfs install
git clone --branch v2.1-new-cards https://github.com/BobrikIndeadlock/Bobrs-Battle-Part-2.git
cd Bobrs-Battle-Part-2
git lfs pull
```

После загрузки откройте `index.html` в браузере.

- `code/js/` и `code/css/` содержат код и стили игры, включая анимации.
- `media/images/` и `media/video/` содержат изображения и ролик из исходной версии.
- `media/deadlock/portraits.js` содержит исходные миниатюры из [Deadlock Wiki](https://deadlock.wiki/Heroes)
  в формате data URL для локальных анимаций героев и экспорта составов в PNG.

## Предыдущая стабильная версия

Тег `v2.0-gothic-final` и резервная ветка `backup/v2.0-gothic-final` указывают на коммит `d64a9f65091cecd1758d7b04848c06095ce5c6a2`. [Скачать архив v2.0](https://github.com/BobrikIndeadlock/Bobrs-Battle-Part-2/raw/gothic-visual-upgrade-downloads/Bobrs-Battle-Part-2-Gothic-Final.zip)

## Второй этап по ссылке

Проведите первый драфт и дождитесь финального ролика. На экране составов выберите «Перейти к драфту Deadlock».

- «Локально» открывает обычный второй этап в игре и работает без интернета.
- «Онлайн с капитаном» открывает размещённую комнату в новой вкладке и переносит оба состава. Ведущий играет за Макарыча и отправляет ссылку Артемону. Второй капитан сразу подключается к комнате.

Составы и драфт остаются в памяти ведущего. Держите его вкладку открытой. При обрыве Артемон может вернуться по той же ссылке из прежнего браузера. Для онлайн-этапа нужна сеть и браузер с WebRTC. [Модуль Deadlock](https://bobrikindeadlock.github.io/Bobrs-Battle-Part-2/)
